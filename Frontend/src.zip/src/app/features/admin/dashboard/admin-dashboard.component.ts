import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AdminService, RegisterUserResponse } from '../../../core/services/admin.service'; // ✅ ajout RegisterUserResponse
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { AdminStatsDto, ActivityItemDto } from '../../../core/models/document';
import { UserDto } from '../../../core/models/auth-response';
import { AuthService } from '../../../core/services/auth.service';
import { normalizeRole } from '../../../core/utils/role.utils';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {

  stats:    AdminStatsDto | null = null;
  users:    UserDto[]            = [];
  activity: ActivityItemDto[]    = [];

  isLoadingStats    = true;
  isLoadingUsers    = true;
  isLoadingActivity = true;
  error             = '';
  isAdmin           = false;
  loadingRoleUserId: string | null = null;

  readonly ROLES: ('User' | 'Manager' | 'Admin')[] = ['User', 'Manager', 'Admin'];

  constructor(
    private adminService: AdminService,
    private modalService: ModalService,
    private toastService: ToastService,
    private authService:  AuthService,
    private cdr:          ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.isAdmin = this.authService.isAdmin();
    this.loadStats();
    this.loadActivity();
    if (this.isAdmin) this.loadUsers();
    else this.isLoadingUsers = false;
  }

  loadStats(): void {
    this.adminService.getStats().subscribe({
      next:  stats => { this.stats = stats; this.isLoadingStats = false; },
      error: (err: Error) => { this.error = err.message; this.isLoadingStats = false; }
    });
  }

  loadUsers(): void {
    this.adminService.getAllUsers().subscribe({
      next: users => {
        this.users = users.map(u => ({ ...u, role: normalizeRole(u.role) }));
        this.isLoadingUsers = false;
      },
      error: (err: Error) => { this.error = err.message; this.isLoadingUsers = false; }
    });
  }

  loadActivity(): void {
    this.adminService.getActivity(10).subscribe({
      next:  act => { this.activity = act; this.isLoadingActivity = false; },
      error: ()  => { this.isLoadingActivity = false; }
    });
  }

  onRoleChange(userId: string, event: Event): void {
    const role = (event.target as HTMLSelectElement).value as 'User' | 'Manager' | 'Admin';
    this.changeRole(userId, role);
  }

  changeRole(userId: string, role: 'User' | 'Manager' | 'Admin'): void {
    this.loadingRoleUserId = userId;
    this.adminService.updateUserRole(userId, role).subscribe({
      next: () => {
        this.users = this.users.map(u =>
          u.id === userId ? { ...u, role } : u
        );
        this.loadingRoleUserId = null;
        this.toastService.success('Rôle mis à jour avec succès.');
        this.cdr.detectChanges();
      },
      error: (err: Error) => {
        this.error = err.message;
        this.loadingRoleUserId = null;
      }
    });
  }

  exportReport(): void {
    this.adminService.exportReport().subscribe({
      next:  () => this.toastService.success('Rapport téléchargé avec succès.'),
      error: () => this.toastService.error('Erreur lors de l\'export.')
    });
  }

  openAddUserModal(): void {
    if (!this.isAdmin) return;
    const result$ = this.modalService.openRegisterModal();
    result$.subscribe({
      next: (data) => {
        if (!data) return;
        this.modalService.setLoading(true);
        this.adminService.registerUser(data).subscribe({
          next: (res: RegisterUserResponse) => { // ✅ type correct
            this.modalService.closeModal();
            const newUser: UserDto = {
              id:        res.userId,
              email:     res.email,
              role:      normalizeRole(res.role),
              createdAt: new Date().toISOString()
            };
            this.users = [newUser, ...this.users];
            if (this.stats) this.stats.totalUsers++;
            this.toastService.success(`Utilisateur ${res.email} créé !`);
          },
          error: (err) => {
            this.modalService.setLoading(false);
            this.toastService.error(err?.error?.message || 'Erreur lors de la création');
          }
        });
      },
      error:    (err) => { console.error(err); this.modalService.closeModal(); },
      complete: () => {}
    });
  }
} 
